/**
 * Created by Amuri on 3/21/2018.
 */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello  world!");
    }
}